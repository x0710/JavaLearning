public enum Status {
    INITIAL, PROHIBITION, ALLOWABLE, RESULTS
}
