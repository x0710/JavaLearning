import java.util.Scanner;

public class Power{
	static Scanner s = new Scanner(System.in);
	public static void main(String[] args){
		
		System.out.print("������");
		float a = s.nextFloat();
		
		System.out.print("ָ����");
		int n = s.nextInt();
		
		System.out.println(run(a,n));
		
	}
	static float run(float a,int n){
		float end = 1;
		for(;n != 0;n--){
			end = end * a;
		}
		return end;
	}
}