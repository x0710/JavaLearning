package Useless;

public class Additional
{
	public static void main(String[] args){
		int x = 0;
		sum(4,0);
		System.out.println(sum(4,0));
	}
	public static int sum(int number,int x){
		if(number != 1){
			 x = number + x;
			 int y = --number;
			 sum(y,x);
		}
		return x;
	}
}
