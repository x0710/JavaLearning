public class MultiplicationTable {

    public static void main(String[] args){

        int y = 9;

        for(;y >= 1;--y){
            for(int x = y;x >= 1;--x){

                System.out.print(x + "*" + y + "=" + y * x + " ");

            }

            System.out.println();

        }

    }

}
