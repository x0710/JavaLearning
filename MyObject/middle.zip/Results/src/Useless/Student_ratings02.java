public class Student_ratings02
{
	public static void main(String[] args){
		
		java.util.Scanner s = new java.util.Scanner(System.in);
		
		System.out.print("ѧ��������");
		double scores = s.nextDouble();
		
		scores = (int)(scores/10.0);
		
		switch ((int)scores){
			case 9 : case 10 : 
			System.out.println("A");
			System.out.println(scores);
			break;
			
			case 8 : 
			System.out.println("B");
			System.out.println(scores);
			break;
			
			case 7 : 
			System.out.println("C");
			System.out.println(scores);
			break;
			
			case 6 : 
			System.out.println("D");
			System.out.println(scores);
			break;
			
			case 5 : case 4 : case 3 : case 2 : case 1 : case 0 :
			System.out.println("E");
			System.out.println(scores);
			break;
			
			default : 
			System.out.println("�Բ���������������");
			System.out.println(scores);
		}
	}

}