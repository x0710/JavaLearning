/**
*���󣺼���ϵͳ����һ�������ĳɼ����ɼ����ܻ����С����
*����ѧ���ĳɼ��жϸ�ѧ���ĳɼ��ȼ���
*     [90-100] A
*     [80-90] B
*     [70-80] C
*     [60-70] D
*     [0-60] E
*/
public class if01{
	public static void main(String[]args){
		
		double wangMing = 101.0;
		double xiaoLiang = 53.0;
		double zhangFang = 86.0;
		double liXiaolong = 97.0;
		double dongDong = 79.0;
		double apple = 61.0;
		
		    if (wangMing > 90){
			    System.out.println("wangming A");
	    	} else if (wangMing > 80) {
			    System.out.println("wangMing B");
			} else if (wangMing > 70) {
				System.out.println("wangMing C");
			} else if (wangMing > 60) {
				System.out.println("wangMing D");
			} else {
				System.out.println("wangMing E");
			}
			
		if (xiaoLiang > 90){
			    System.out.println("xiaoLiang A");
	    	} else if (xiaoLiang > 80) {
			    System.out.println("xiaoLiang B");
			} else if (xiaoLiang > 70) {
				System.out.println("xiaoLiang C");
			} else if (xiaoLiang > 60) {
				System.out.println("xiaoLiang D");
			} else {
				System.out.println("xiaoLiang E");
			}
			
		if (zhangFang > 90){
			    System.out.println("zhangFang A");
	    	} else if (zhangFang > 80) {
			    System.out.println("zhangFang B");
			} else if (zhangFang > 70) {
				System.out.println("zhangFang C");
			} else if (zhangFang > 60) {
				System.out.println("zhangFang D");
			} else {
				System.out.println("zhangFang E");
			}
		
		if (liXiaolong > 90){
			    System.out.println("liXiaolong A");
	    	} else if (liXiaolong > 80) {
			    System.out.println("liXiaolong B");
			} else if (liXiaolong > 70) {
				System.out.println("liXiaolong C");
			} else if (liXiaolong > 60) {
				System.out.println("liXiaolong D");
			} else {
				System.out.println("liXiaolong E");
			}
		if (dongDong > 90){
			    System.out.println("dongDong A");
	    	} else if (dongDong > 80) {
			    System.out.println("dongDong B");
			} else if (dongDong > 70) {
				System.out.println("dongDong C");
			} else if (dongDong > 60) {
				System.out.println("dongDong D");
			} else {
				System.out.println("dongDong E");
			}
		if (dongDong > 90){
			    System.out.println("apple A");
	    	} else if (apple > 80) {
			    System.out.println("apple B");
			} else if (apple > 70) {
				System.out.println("apple C");
			} else if (apple > 60) {
				System.out.println("apple D");
			} else {
				System.out.println("apple E");
			}
	}
}