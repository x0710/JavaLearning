package Abandon;

/*
2 3 5 7 11 13 19 17 23 29 31 37 43 53
*/
public class Prime{
	public static void main(String[] args){
		System.out.print("2 3 5 7 11 13 17 19 ");
		int number01 = 5;
		for(int number = 3;number <= 10000;number = number + 2){
			if(number % 3 != 0){
				if(number % number01 != 0){
				number01 = number;
				System.out.println(number);
				}
			}
		}
	}
	
}
