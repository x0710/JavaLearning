public class Test01
{
	public static void main(String[] args){
		java.util.Scanner s = new java.util.Scanner(System.in);
		int X = s.nextInt();
		if(X <= 0){
			System.out.println("�ݲ�֧��0��С��0������");
		}else{
		sum(X);
		System.out.println(sum(X));	
		}
	}
	public static int sum(int a){
		int Y = 0;
		int Z = 0;
		if(Y != a){
			Y++;
			Z = Y + Z;
			sum(Y);
			return Z;
		}else {
			return Z;
		}
	}
}