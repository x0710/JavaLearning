public class Temporary{
	public static void main(String[] args){
		
	}
}
class Information{
	private String password;
	private String username;
	public String getUsername(){
		return username;
	}
	public String getPassword(){
		return password;
	}
	public void setPassword(String x){
		password = x;
	}
	public void setUsername(String x){
		username = x;
	}
}