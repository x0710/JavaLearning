public class Additional
{
	public static void main(String[] args){
		System.out.println("???????????????1+2+3+4=10??");
		java.util.Scanner s = new java.util.Scanner(System.in);
		System.out.print("???");
		int x = s.nextInt();
		System.out.print("?????");
		int z = s.nextInt();
		int number = 0;
		if(z <= 0){
			System.out.println("?????");
		}else{
			int y = 0;
			for(;y != x;){
				y = y + z;
				number = y + number;
			}
			System.out.println("???" + number);
		}
	}
}