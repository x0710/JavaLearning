public class BinaryConverter
{
    long over;
    static BinaryConverter zhu = new BinaryConverter();
    static java.util.Scanner s = new java.util.Scanner(System.in);
    static{
        System.out.println("请讲转换的二进制码反过来，这才是结果");
        System.out.println("\u6ce8\u610f\uff1a\u8f93\u51fa\u7684\u7ed3\u679c\u987a\u5e8f\u662f\uff1a\u81ea\u4e0b\u800c\u4e0a" + " " + "\u5e76\u975e\u81ea\u4e0a\u800c\u4e0b");
        System.out.println("\r");
    }
    /**
     * 主程序
     */
    public static void main(String[] args)
 {
        for (int a = 1;a == 1;)
        {
             System.out.println("10进制转2进制输入102");
             System.out.println("2进制转10进制输入210");
             System.out.println("停止请输入0");

           System.out.print("代码：");
           int kong = s.nextInt();
           if (kong == 102)
           {
               TenOfTwo();
           }
           else if (kong == 210)
           {
           	TwoOfTen();
           }
           else if (kong == 0)
           {
           	a = 0;
           }
           else
           {
           	System.out.println("未找到代码");
           	System.out.println("继续请输入1");
            	a = s.nextInt();
            }
        }
    }

    /**
     * 运算程序
     * 十进制转二进制
     */
    public static void TenOfTwo()
    {
        System.out.print("十进制：");
        int a = s.nextInt();
        System.out.println("\n");

        if (a == 0)
        {
        	System.out.println(0);
        }
        else
        {
            FOR:for (;a != 0;)
            {
                if (a < 0)
                {
                    System.out.println("\u6682\u4e0d\u652f\u6301\u5c0f\u4e8e" + "0" + "\u7684\u8fd0\u7b97");
                    break FOR;
                }
                else if (a % 2 == 0)
                {
                    System.out.print(0);
                    a = a / 2;
                }
                else if (a % 2 == 1)
                {
                    System.out.print(1);
                    a = a / 2;
                }
                else
                {
                    System.out.println("\u53d1\u751f\u672a\u77e5\u9519\u8bef");
                    break FOR;
                }
            }
        }
        System.out.println("\n");
    }

    /**
     * 运算程序
     * 二进制转十进制
     */
    public static void TwoOfTen()
    {
    	int c = 0;
    	System.out.println("输入1000停止，1001清空");
        System.out.println("\r");

        int a = 0;

        FOR:for (;;)
        {
            System.out.print("二进制码（代码）：");
            a = s.nextInt();
        	if (a == 1)
            {
            		c = c * 2 + 1;
            		System.out.println("临时结果" + c);
        	}else if (a == 0){
        		c = c * 2 + 0;
        		System.out.println("临时结果" + c);
        	}
            else if (a == 1000)
            {
             System.out.println("\r");
        		break FOR;
        	}
            else if (a == 1001)
            {
        		c = 0;
        		System.out.println("\r");
        	}
            else
            {
        		System.out.println("请输入 1或0");
        		break FOR;
        	}
        }
    }
}
