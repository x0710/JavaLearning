import java.util.Scanner;
/**
 * 1.输入x
 * 2.*（-3）
 * 3.-2
 * 4.输出
 */
public class ISBN9787107326059P31_5{
    public static void main(String[] args){

        Scanner s = new Scanner(System.in);

        long x =s.nextLong();

        System.out.println((x * (-3)) - 2);

    }
}
