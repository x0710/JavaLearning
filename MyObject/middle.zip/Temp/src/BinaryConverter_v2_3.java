import java.util.Scanner;

public class BinaryConverter_v2_3
{
	static Scanner s = new Scanner(System.in);
	
    public static void main(String[] args)
	{
		for(int a = 1;a != 0;){
			System.out.println("\nback:does 0\nTen Of Two:102");
			a = s.nextInt();
			if(a == 102){
				tenOfTwo();
			}
		}
		System.out.println("The End.");
	}
	
	public static void tenOfTwo(){
		
		//输入
		System.out.print("start:");
		long number = s.nextLong();
		//判断，拦截
		if (number < 0)
		{
			System.out.println("ERROW");
			return;
		}

		//创建临时的数字，用于for
		long tempnumber = number;
		//设置二进制码数量——64
        byte[] onezero = new byte[64];

		for(byte a = 1;a <= 63;++a){
			if(Tf.tf(tempnumber) == true)
			{
				onezero[a - 1] = 1;
			}
			else if(Tf.tf(tempnumber) == false){
				onezero[a - 1] = 0;
			}
			tempnumber = tempnumber / 2;
		}	
		end(onezero);	
	}
	private static void end(byte[] onezero){
		//输出最终结果
		System.out.print("OVER:");
		for (byte c = 64;c >= 1;)
		{
			for(byte xy = 4;xy >= 1;) {
				System.out.print(onezero[c - 1]);
				c--;
				xy--;
			}
			System.out.print("");
			System.out.print(" ");
		}
	}
}

/**
 * 工具包
 */
class Tf{
	
	/**
	 * tf方法(TRUE FALSE)传入一个int类型参数，是否可以被2整除
	 * 如果可以被2整除，返回false。反之是true
	 * 如果得到的不是1或0，则返回false
	 */
	public static boolean tf(long a){
		if(a % 2 == 1){
			return true;
		}else if(a % 2 == 0){
			return false;
		}else{
			return false;
		}
	}
	
}

