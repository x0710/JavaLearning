public class BinaryConverter_v2_0 extends java.lang.Object{
    public static void main(String[] args){
        byte[] onezero = new byte[64];
    }
}
