package Calculator.Continuous;

public class Main {
    static Main m = new Main();
    long product = 1;
    public Main(){
    }
    public Main(int a,char b){
        if(b == '!' || b == '*'){
            for(int c = b;c >= 1;c--){
                m.product *= c;
            }
        }
    }
}
