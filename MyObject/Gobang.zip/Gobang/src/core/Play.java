package core;

public interface Play
{
	Chess play(Board now);
}
