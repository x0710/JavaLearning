package core;

/**
* 棋子的颜色
*/
public enum Color {
	BLACK, WHITE;
	
}
