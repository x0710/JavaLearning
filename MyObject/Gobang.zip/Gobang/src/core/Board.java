package core;
import java.util.*;

public class Board implements Cloneable
{
	public static final String WHITE = "○", 
		BLACK = "●", NULL = "×";
	
	private int length, width;
	private Set<Chess> chesses;
	
	public Board(int length, int width) {
		this.length = length;
		this.width = width;
		chesses = new HashSet<>();
		/*
		chesses.add(new Chess(Color.BLACK, 1, 6));
		chesses.add(new Chess(Color.WHITE, 2, 7));
		chesses.add(new Chess(Color.BLACK, 3, 8));
		chesses.add(new Chess(Color.BLACK, 4, 9));
		*/
	}
	/**
	* 放置一个棋子
	* @param chess 被放置的棋子
	* @return 是否放置成功
	*/
	public boolean setChess(Chess chess) {
		if(chess.getY() < 0 || chess.getX() < 0) 
			return false;
		if(chess.getX() > length || chess.getY() > width) 
			return false;
		return chesses.add(chess);
	}
	public Collection getBoard() {
		try {
			return (Collection)(super.clone());
		}
		catch(CloneNotSupportedException e) {
			e.printStackTrace();
			return null;
		}
	}
	public boolean hasChess(Note chess) {
//		System.out.println(chesses.contains(chess));
		return chesses.contains(chess);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for(int i = 0;i < length;i++) {
			for(int j = 0;j < width;j++) {
				Chess ctW = new Chess(Color.WHITE, i, j);
				Chess ctB = new Chess(Color.BLACK, i, j);
				if(chesses.contains(ctW)) {
					sb.append(WHITE+" ");
				}
				else if(chesses.contains(ctB)) {
					sb.append(BLACK+" ");
				}
				else {
					sb.append(NULL + " ");
				}
			}
			sb.append(System.lineSeparator());
		}
		return sb.toString();
	}
	public Chess[] getChesses() {
		return null;
	}
	
}
