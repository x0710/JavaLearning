package players;

import core.Player;
import core.*;

public class AIPlayer extends Player {
	@Override
	public Chess play(Board now) {
		return null;
	}

	
}
