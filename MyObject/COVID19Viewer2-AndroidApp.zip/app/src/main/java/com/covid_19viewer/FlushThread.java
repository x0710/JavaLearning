package com.covid_19viewer;
import android.widget.*;

public class FlushThread implements Runnable 
{
	private Viewer v;
	private TextView tv;
	
	
	public FlushThread(TextView tv) {
		
		this.tv = tv;
	}
	public void run() {
		while(true) {
			synchronized(this) {
				try {
					
					super.wait();
					tv.setText("wait");
				}
				catch(InterruptedException e) {
					tv.setText(e.toString());
				}
				catch(Exception e) {
					tv.setText(e.toString());
				}
			}
			
			v = new Viewer();
			if(v != null) 
				tv.setText(v.toString());
		}
	}
	
}

