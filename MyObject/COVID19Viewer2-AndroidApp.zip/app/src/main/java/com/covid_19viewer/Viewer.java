package com.covid_19viewer;

import java.net.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;

public class Viewer {
	private URL u;
	
	private long confirmedCases, 
		deathCases;
	private String range;
	String e;

	private Date time;

	public Viewer() {
		handle();
		
	}
	public long getConfirmedCases() {
		return confirmedCases;
	}
	public long getDeathCases() {
		return deathCases;
	}
	public String getRange() {
		return range;
	}
	public Date getTime() {
		return time;
	}
	private void handle() {
		try {
			u = new URL("https://covid19.who.int");
			setValue(getStreamData());
			return;
		}
		catch(UnknownHostException e) {
			this.e = ("请检查网络连接，网址是否过时");
		}
		catch(NullPointerException e) {
			e.printStackTrace();
			this.e = e.toString();
		}
		catch(ConnectException ce) {
			this.e = ("服务器无响应");
		}
		catch(IOException ioe) {
			this.e = ("发生IO错误");
			ioe.printStackTrace();
		}
		catch(Exception e) {
			this.e = ("数据接收失败");
			this.e = e.toString();
		}
		//System.exit(0);
	}
	private StringBuilder getStreamData() throws IOException {
		System.out.println("正在连接服务器");
		BufferedReader br = new BufferedReader(new InputStreamReader(u.openStream(), "UTF-8"));
		System.out.println("开始接收数据...");
		StringBuilder sb = new StringBuilder(10*10000);
		for(String t;(t = br.readLine()) != null;)
			sb.append(t);
		br.close();
		return sb;
	}
	private void setValue(CharSequence val) throws ParseException {
		System.out.println("数据处理中");
		Pattern regex = Pattern.compile("<span\\sclass=\".*?\">(.*?)<\\/span>");
		Matcher main = regex.matcher(val);
		Matcher spare = Pattern.compile("<span\\sclass=\".*?\">([\\d,]+)<!--\\s-->").matcher(val);
		if(main.find())
			range = main.group(1);


		if(main.find())
			time = new SimpleDateFormat("hh:mmaa dd MMMMM yyyy", Locale.US).parse(main.group(1).replaceAll("CES?T,\\s", ""));
		time.setHours(time.getHours() + 6);


		if(spare.find())
			confirmedCases = Long.parseLong(spare.group(1).replace(",", ""));
		if(spare.find())
			deathCases = Long.parseLong(spare.group(1).replace(",", ""));

	}

	@Override
	public String toString() {
		if(e != null) //如果Date为null，则发生异常
			return e;
		// TODO: Implement this method
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd  HH:mm ");
		StringBuilder sb = new StringBuilder(128);
		DecimalFormat df = new DecimalFormat("####,####,####");
		//2:16pm CEST, 18 August 2020
		//2:16pm 18 August 2020

		sb.append("统计时间：" + sdf.format(time) + "\r\n");
		sb.append("区域范围：" + range + "\r\n");
		sb.append("确诊病例：" + df.format(confirmedCases) + "\r\n");
		sb.append("死亡病例：" + df.format(deathCases) + "\r\n");
		sb.append("数据来源：" + u.getHost());

		return sb.toString();
	}

}
