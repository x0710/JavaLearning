package com.covid_19viewer;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.View.*;
import android.view.View;

public class MainActivity extends Activity 
{
	private TextView tv;
	private Thread t;
	private FlushThread ft;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		/*
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);
		*/
		tv = (TextView)findViewById(R.id.output);
		Button flush = (Button)findViewById(R.id.flush);
		/*
		flush.setOnClickListener(new OnClickListener() {
			public void onClick(View p1) {
				v = new Viewer();
				tv.setText(v.toString());
			}
		});
		*/
		ft = new FlushThread(tv);
		t = new Thread(ft);
		t.start();
		flush.setOnClickListener(new OnClickListener() {
			public void onClick(View p1) {
				synchronized(ft) {
					
					try {
						ft.notify();
					}
					catch(Exception e) {
						tv.setText(e.toString());
					}
				}
				
			}
		});
    }
}
